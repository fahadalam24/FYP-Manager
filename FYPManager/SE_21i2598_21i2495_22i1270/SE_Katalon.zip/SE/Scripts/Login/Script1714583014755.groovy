import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('http://localhost:49965/SignIn.aspx')

WebUI.click(findTestObject('Object Repository/Page_Login/input_Username_UsernameTxt'))

WebUI.setText(findTestObject('Object Repository/Page_Login/input_Username_UsernameTxt'), 'fac_Rasab')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_Login/input_Password_PasswordTxt'), 'tzH6RvlfSTg=')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_Login/select_-- Select Role --StudentSupervisorPa_33beb0'), 
    'Panel Member', true)

WebUI.click(findTestObject('Object Repository/Page_Login/input_Role_LoginBtn'))

WebUI.click(findTestObject('Object Repository/Page_/a_Evaluations'))

WebUI.click(findTestObject('Object Repository/Page_/td_1_2'))

WebUI.click(findTestObject('Object Repository/Page_/td_1'))

WebUI.click(findTestObject('Object Repository/Page_/input_min_ctl00ContentPlaceHolder1Rating1'))

WebUI.click(findTestObject('Object Repository/Page_/input_min_ctl00ContentPlaceHolder1Rating2'))

WebUI.click(findTestObject('Object Repository/Page_/input_min_ctl00ContentPlaceHolder1Rating3'))

WebUI.click(findTestObject('Object Repository/Page_/input_min_ctl00ContentPlaceHolder1Rating4'))

WebUI.click(findTestObject('Object Repository/Page_/input_min_ctl00ContentPlaceHolder1Rating5'))

WebUI.click(findTestObject('Object Repository/Page_/input_min_ctl00ContentPlaceHolder1Rating6'))

WebUI.click(findTestObject('Object Repository/Page_/input_min_ctl00ContentPlaceHolder1Rating7'))

WebUI.click(findTestObject('Object Repository/Page_/input_min_ctl00ContentPlaceHolder1Rating8'))

WebUI.click(findTestObject('Object Repository/Page_/input_min_ctl00ContentPlaceHolder1Rating9'))

WebUI.click(findTestObject('Object Repository/Page_/input_min_ctl00ContentPlaceHolder1Rating10'))

WebUI.click(findTestObject('Object Repository/Page_/input_min_ctl00ContentPlaceHolder1Rating11'))

WebUI.click(findTestObject('Object Repository/Page_/input_min_ctl00ContentPlaceHolder1Rating12'))

WebUI.click(findTestObject('Object Repository/Page_/input_min_ctl00ContentPlaceHolder1Rating13'))

WebUI.click(findTestObject('Object Repository/Page_/input_min_ctl00ContentPlaceHolder1Rating14'))

WebUI.click(findTestObject('Object Repository/Page_/input_min_ctl00ContentPlaceHolder1Rating15'))

WebUI.setText(findTestObject('Object Repository/Page_/input_Comments_ctl00ContentPlaceHolder1TextBox3'), 'Great Work')

WebUI.click(findTestObject('Object Repository/Page_/input_Comments_ctl00ContentPlaceHolder1Button1'))

