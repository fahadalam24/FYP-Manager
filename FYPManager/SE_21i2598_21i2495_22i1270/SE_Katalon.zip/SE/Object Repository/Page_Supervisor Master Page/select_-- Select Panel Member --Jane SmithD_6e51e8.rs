<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_-- Select Panel Member --Jane SmithD_6e51e8</name>
   <tag></tag>
   <elementGuidId>1654e94e-842e-436e-aaba-a14203f2782c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='MainContent_ddlPanelMembers']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#MainContent_ddlPanelMembers</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#MainContent_ddlPanelMembers</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>b95e5267-7c7a-4f8d-b361-ac191da2445c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>ctl00$MainContent$ddlPanelMembers</value>
      <webElementGuid>86553000-b130-47cc-8808-9a95c6d42dd7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>MainContent_ddlPanelMembers</value>
      <webElementGuid>cacb46f9-1510-4537-9805-52837c4b1266</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>c23ba783-b7bd-4abe-b770-1686814a5d42</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	-- Select Panel Member --
	Jane Smith
	David Johnson

</value>
      <webElementGuid>5a5a5678-714e-4706-8379-d04350818a98</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;MainContent_ddlPanelMembers&quot;)</value>
      <webElementGuid>b917c10a-310a-4edb-99b3-eb8149e8f704</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='MainContent_ddlPanelMembers']</value>
      <webElementGuid>bd0f0cf5-6ce9-4c3f-b956-bb524af5c5f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='form1']/div[3]/div/select</value>
      <webElementGuid>9dcd8e02-54da-4799-9ca4-f23d2ea1d39b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Make A Suggestion'])[1]/following::select[1]</value>
      <webElementGuid>05151d88-8f5f-4c90-a908-27127b75d660</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Logout'])[1]/following::select[1]</value>
      <webElementGuid>94f98b60-8ae2-45ed-9b49-837d27039d99</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>1ab650f4-65b9-48fd-ac2d-bafdbbb7bdf7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'ctl00$MainContent$ddlPanelMembers' and @id = 'MainContent_ddlPanelMembers' and (text() = '
	-- Select Panel Member --
	Jane Smith
	David Johnson

' or . = '
	-- Select Panel Member --
	Jane Smith
	David Johnson

')]</value>
      <webElementGuid>1aff4d5a-6706-4995-9269-ff22a83db005</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
