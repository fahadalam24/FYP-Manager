<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Fahad AlamRasab ZahidSharjeel Zahid</name>
   <tag></tag>
   <elementGuidId>5614b101-ec49-476a-9702-0c30e13f1119</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='MainContent_PanelLeaderDdl']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#MainContent_PanelLeaderDdl</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#MainContent_PanelLeaderDdl</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>4720f295-a766-4bb9-a8f9-4ad6998df9c2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>ctl00$MainContent$PanelLeaderDdl</value>
      <webElementGuid>a04547f8-e6e1-4d01-9289-d39f2f0325aa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>MainContent_PanelLeaderDdl</value>
      <webElementGuid>a4931437-bc6a-4134-942a-b6d3c859f245</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>1f735d11-7757-404d-8a1b-53b572a771db</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	Fahad Alam
	Rasab Zahid
	Sharjeel Zahid

</value>
      <webElementGuid>990071b8-fcd0-4367-9b1b-3fa3e6709464</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;MainContent_PanelLeaderDdl&quot;)</value>
      <webElementGuid>b547893a-95fe-4e38-ac95-3cd542a4bb5c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='MainContent_PanelLeaderDdl']</value>
      <webElementGuid>8a9d6e99-6a8e-42fe-9b5d-d419c245163e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='form1']/div[3]/div/div[2]/div[2]/select</value>
      <webElementGuid>e9a30d3f-a348-4df0-bf60-7550b5f36918</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Panel Leader'])[1]/following::select[1]</value>
      <webElementGuid>9eb9c675-c5bd-4df0-b7e9-9056106e7d84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sharjeel Zahid'])[1]/following::select[1]</value>
      <webElementGuid>8bfd2111-3591-4df9-ad4e-312ba95290fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Message'])[1]/preceding::select[1]</value>
      <webElementGuid>8026532b-7dcc-4853-bce2-c3f9c9365cf8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Close'])[1]/preceding::select[1]</value>
      <webElementGuid>01b0206d-0707-40dd-b8d0-52ff779145e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>1442910a-475e-4642-80e1-5a98815cf9ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'ctl00$MainContent$PanelLeaderDdl' and @id = 'MainContent_PanelLeaderDdl' and (text() = '
	Fahad Alam
	Rasab Zahid
	Sharjeel Zahid

' or . = '
	Fahad Alam
	Rasab Zahid
	Sharjeel Zahid

')]</value>
      <webElementGuid>2a1eea9c-706f-4bac-8f4a-e74e9a411d7f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
