<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_-- Select Role --StudentSupervisorPa_33beb0</name>
   <tag></tag>
   <elementGuidId>5f1c868e-146b-4eb6-8782-e278785b54c4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='RoleDdl']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#RoleDdl</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#RoleDdl</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>357a4521-556b-49bc-9bf4-f6a04995b4c6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>RoleDdl</value>
      <webElementGuid>c6e82586-59db-4769-99f7-826c0b2046da</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>RoleDdl</value>
      <webElementGuid>fcb13b26-0539-4ac0-b638-5b991764701d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-box</value>
      <webElementGuid>65da10a2-17aa-43f9-bb65-07be8182e919</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	-- Select Role --
	Student
	Supervisor
	Panel Member
	Committee Member

</value>
      <webElementGuid>c3d8cd5e-4abd-41cb-8a33-54da5243d97d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;RoleDdl&quot;)</value>
      <webElementGuid>10031160-06b7-4716-95a2-a26ab71ec65c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='RoleDdl']</value>
      <webElementGuid>b61c4163-7455-4e34-b745-6e51c6719fe2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='form1']/div[3]/select</value>
      <webElementGuid>eb51f6bf-2004-4888-9234-d84d99aee59c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Role'])[1]/following::select[1]</value>
      <webElementGuid>a73afc0c-b883-4b55-bb0a-5c5708b48440</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Password'])[1]/following::select[1]</value>
      <webElementGuid>bfa8c416-2517-4129-b304-b4b3ac047da7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>e1f33980-cc4f-474d-a384-41b92d46e5cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'RoleDdl' and @id = 'RoleDdl' and (text() = '
	-- Select Role --
	Student
	Supervisor
	Panel Member
	Committee Member

' or . = '
	-- Select Role --
	Student
	Supervisor
	Panel Member
	Committee Member

')]</value>
      <webElementGuid>10560f51-0698-44b3-aa3f-e4f3ff486063</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
